package service;

import bean.DemandDraftDetails;
import exception.DemandDraftDBException;
import exception.InvalidDemandDraftException;

public interface DdService {
	
	
	public int addDemandDraftDetails(DemandDraftDetails dd) throws DemandDraftDBException;
	public DemandDraftDetails getDemandDraftDetails(int tId) throws DemandDraftDBException;
	public boolean isValidDetail(DemandDraftDetails dd) throws InvalidDemandDraftException;

}
