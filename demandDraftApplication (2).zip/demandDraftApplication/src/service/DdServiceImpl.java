package service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import bean.DemandDraftDetails;
import dao.DemandDraftDao;
import dao.DemandDraftDaoImpl;
import exception.DemandDraftDBException;
import exception.InvalidDemandDraftException;

public class DdServiceImpl implements DdService {

	DemandDraftDao edao = new DemandDraftDaoImpl();

	public DdServiceImpl() {
	}

	public int addDemandDraft(DemandDraftDetails bean) throws DemandDraftDBException {
		return edao.addDemandDraftDetails(bean);
	}

	public DemandDraftDetails getDdDetails(int tId) throws DemandDraftDBException {
		return edao.getDemandDraftDetails(tId);
	}



	public boolean isValidDetail(DemandDraftDetails bean)
			throws InvalidDemandDraftException {
//		if (!bean.getCustomer_name().matches("^[A-Z][a-z]{2,14}$")) {
//			
//			throw new InvalidDemandDraftException(
//					"Please enter a correct first name\n"
//							+ "First name should start with capital letter and it should be of 3-15 letters");
//		}
//		if (!bean.getIn_favor_of().matches("^[A-Z][a-z]{2,14}$")) {
//		
//			throw new InvalidDemandDraftException(
//					"Please enter a correct last name\n"
//							+ "Last name should start with capital letter and it should be of 3-15 letters");
//		}
//		if (!bean.getPhone_no().matches("^[6-9][0-9]{9}$")) {
//			
//			throw new InvalidDemandDraftException(
//					"Please enter a correct contact number!!!\n "
//							+ "Contact number should be of 10 digits and it should start from 6 onwards");
//		}
//		if (Integer.parseInt(bean.getDd_amount()) < 100) {
//		
//			throw new InvalidDemandDraftException(
//					"Please enter Ammount Greater than 100");
//		}
		return true;
	}

	public boolean validateTId(String tId) {

		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(tId);

		if (idMatcher.matches())
			return true;
		else
			return false;
	}

	public int addDemandDraftDetails(DemandDraftDetails dd)
			throws DemandDraftDBException {
		// TODO Auto-generated method stub
		return edao.addDemandDraftDetails(dd);
	}

	public DemandDraftDetails getDemandDraftDetails(int tId)
			throws DemandDraftDBException {
		// TODO Auto-generated method stub
		return edao.getDemandDraftDetails(tId);
	}
}
