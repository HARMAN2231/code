package pi;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

import service.DdService;
import service.DdServiceImpl;
import bean.DemandDraftDetails;
import exception.DemandDraftDBException;
import exception.InvalidDemandDraftException;

public class DdMain {

	static Scanner scanner = new Scanner(System.in);
	 static SimpleDateFormat myFormat = new SimpleDateFormat("dd MM yyyy");
	static DdService ddService = null;
	static DdServiceImpl ddServiceImpl = null;


	public static void main(String[] args) {

		DemandDraftDetails bean = null;
		DdService service = new DdServiceImpl();
		String tId = null;
		int option = 0;

		while (true) {

			
			System.out.println();
			System.out.println();
			System.out.println("   XYZ BANKING SYSTEM ");
			System.out.println("_______________________________\n");

			System.out.println("1.Enter New Demand Draft  ");
			System.out.println("2.View Demand Draft Detail");
			System.out.println("3.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			

			try {
				option = scanner.nextInt();

				switch (option) {

				case 1:
					
					bean = new DemandDraftDetails();
					System.out.println("Enter Customer name : ");
					String Cname = scanner.next();
					bean.setCustomer_name(Cname);
					System.out.println("Enter In-Favour-of : ");
					String iname = scanner.next();
					bean.setIn_favor_of(iname);
					System.out.println("Enter Phone Number : ");
					String contact = scanner.next();
					bean.setPhone_no(contact);
					System.out.println("Enter Date of Transaction (dd/mm/yy):");
			        String cindate = scanner.next();
//			        Date date=null;
//					try {
//						date = myFormat.parse(cindate);
//					} catch (ParseException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
			        bean.setDate_of_transaction(cindate);
					System.out.println("Enter your Demand Draft Ammount : ");
					String ammount = scanner.next();
					bean.setDd_amount(ammount);
					System.out.println("Enter your Demand Draft comm : ");
					String dd_comm = scanner.next();
					bean.setDd_comm(dd_comm);
					System.out.println("Enter your Demand Draft Description : ");
					String desc = scanner.next();
					bean.setDd_desciption(desc);
					
					try {
						if (service.isValidDetail(bean)) {
							int tid = service.addDemandDraftDetails(bean);
//						
							System.out.println("Thank you For Making Demand Draft \n"+
							"Your unique id is "+bean.getTransaction_id()+ " "+"We will contact you soon");
						}
					} catch (InvalidDemandDraftException e) {
//						
						System.err.println(e.getMessage());
					}catch(DemandDraftDBException e){
//						
						System.err.println(e.getMessage());
					}
					break;

				case 2:
					
					DdServiceImpl service2 = new DdServiceImpl();
					System.out.println("Enter numeric donor id:");
					tId = scanner.next();

					while (true) {
						if (service2.validateTId(tId)) {
							break;
						} else {
							System.err
									.println("Please enter numeric donor id only, try again");
							tId = scanner.next();
						}
					}

					try {
						bean = service.getDemandDraftDetails(Integer.parseInt(tId));
					} catch (DemandDraftDBException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					if (bean != null) {
						System.out.println("Transaction Id             :"
								+ bean.getTransaction_id());
						System.out.println("Customer Name             :"
								+ bean.getCustomer_name());
						System.out.println("Date Of Transaction          :"
								+ bean.getDate_of_transaction());
						System.out.println("Phone Number     :"
								+ bean.getPhone_no());
						System.out.println("Demand Draft Ammount       :"
								+ bean.getDd_amount());
						System.out.println("Demand Draft Description  :"
								+ bean.getDd_desciption());
					} else {
						System.err
								.println("There are no donation details associated with donor id "
										+ tId);
					}

					break;

				case 3:

					System.out.print("Exit Trust Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}
			}

			catch (InputMismatchException e) {
				scanner.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}
	}

	
}
