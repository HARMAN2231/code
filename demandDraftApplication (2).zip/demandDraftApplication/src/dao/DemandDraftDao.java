
package dao;

import bean.DemandDraftDetails;
import exception.DemandDraftDBException;

public interface DemandDraftDao {
	
	
	public int addDemandDraftDetails(DemandDraftDetails dd) throws DemandDraftDBException;
	public DemandDraftDetails getDemandDraftDetails(int tId) throws DemandDraftDBException;
}
