package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import util.DataBaseConnection;
import bean.DemandDraftDetails;
import exception.DemandDraftDBException;

public class DemandDraftDaoImpl implements DemandDraftDao {

	

	Connection conn = null;
	 static SimpleDateFormat myFormat = new SimpleDateFormat("dd MM yyyy");
	public DemandDraftDaoImpl() {
		
	}

	private int generateTId() throws DemandDraftDBException {
		String eid = null;
		try {
			conn = DataBaseConnection.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rst = stmt
					.executeQuery(QueryMapper.TRANCATIONID_SEQUENCE_QUERY);
			while (rst.next()) {
				eid = rst.getString(1);
			}

		} catch (SQLException e) {
		
			throw new DemandDraftDBException("Problem in generating enquiry id");
		}
		return Integer.parseInt(eid);

	}

	public DemandDraftDetails getDemandDetails(String tId) throws DemandDraftDBException {
		
		return null;
	}

	public int addDemandDraftDetails(DemandDraftDetails bean) throws DemandDraftDBException {
		// TODO Auto-generated method stub
		bean.setTransaction_id(generateTId());
		try {
			conn = DataBaseConnection.getConnection();
			PreparedStatement pst = conn
					.prepareStatement(QueryMapper.ADD_DETAIL_QUERY);
			pst.setInt(1, bean.getTransaction_id());
			pst.setString(2, bean.getCustomer_name());
			pst.setString(3, bean.getIn_favor_of());
			pst.setString(4, bean.getPhone_no());
			pst.setString(5, bean.getDd_amount());
			pst.setString(6, bean.getDd_comm());
			pst.setString(7, bean.getDd_desciption());
			pst.executeUpdate();
		} catch (SQLException e) {

			throw new DemandDraftDBException("Problem in adding enquiry details\n");
		}
		return bean.getTransaction_id();
	}


	public DemandDraftDetails getDemandDraftDetails(int tId) throws DemandDraftDBException {
		// TODO Auto-generated method stub

		DemandDraftDetails enq = null;
		try {
			conn = DataBaseConnection.getConnection();
			PreparedStatement pst = conn
					.prepareStatement(QueryMapper.GET_DemandDetail_QUERY);
			pst.setInt(1, tId);
			ResultSet rst = pst.executeQuery();
			if (rst.next()) {
				enq = new DemandDraftDetails();
				enq.setTransaction_id(Integer.parseInt(rst.getString("tractionId")));
				enq.setCustomer_name(rst.getString("customerName"));
				enq.setIn_favor_of(rst.getString("in_favor_of"));
				enq.setPhone_no(rst.getString("contactno"));
				enq.setDate_of_transaction(rst.getString("dateOfTransaction"));
				enq.setDd_amount(rst.getString("dd_ammount"));
				enq.setDd_comm(rst.getString("dd_comm"));
				enq.setDd_desciption(rst.getString("dd_description"));
			}
		} catch (SQLException e) {
			throw new DemandDraftDBException(
					"Problem in searching enquiry details\n");
		}
		return enq;
	}

}
